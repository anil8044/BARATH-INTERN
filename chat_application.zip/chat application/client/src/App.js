import "./App.css";
import io from "socket.io-client";
import { useState } from "react";
import Chat from "./Chat";
import img from "./img1.jpg";

const socket = io.connect("http://localhost:3001");

function App() {
  const [username, setUsername] = useState("");
  const [room, setRoom] = useState("");
  const [showChat, setShowChat] = useState(false);

  const joinRoom = () => {
    if (username !== "" && room !== "") {
      socket.emit("join_room", room);
      setShowChat(true);
    }
  };

  return (
    <div className="App">
      <div className="img">
        
      <img src={img}  height="flex"/>
      </div>
      {!showChat ? (
        <div className="joinChatContainer">
          <h3>Join  Chat</h3>
          <input
            type="text"
            placeholder="Enter Your Name..."
            onChange={(event) => {
              setUsername(event.target.value);
            }}
          />
          <input
            type="text"
            placeholder="Enter  room ID..."
            onChange={(event) => {
              setRoom(event.target.value);
            }}
          />
          <button onClick={joinRoom}>Click to Join Room</button>
        </div>
      ) : (
        <Chat socket={socket} username={username} room={room} />
      )}
    </div>
  );
}

export default App;
