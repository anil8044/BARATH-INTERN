const reportWebVitals = onPerfEntry => {
};

export default reportWebVitals;
